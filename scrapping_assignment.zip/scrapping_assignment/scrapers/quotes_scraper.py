import logging
from urllib.parse import urljoin

from bs4 import BeautifulSoup
from scrapers.base_scraper import polite_delay


logger = logging.getLogger(__name__)

START_URL = "https://quotes.toscrape.com/"


def scrape_quotes(session):
    records = []
    url = START_URL
    page_number = 1

    while url:
        logger.info("Quotes page %d: %s", page_number, url)

        try:
            response = session.get(url, timeout=10)
            response.raise_for_status()
            response.encoding = "utf-8"

        except Exception as exc:
            logger.error("Failed to fetch %s: %s", url, exc)
            break

        soup = BeautifulSoup(response.text, "lxml")

        for quote in soup.select("div.quote"):
            try:
                text_element = quote.select_one("span.text")
                author_element = quote.select_one("small.author")

                tags = [
                    tag.get_text(strip=True)
                    for tag in quote.select("a.tag")
                ]

                author_link = quote.select_one('a[href^="/author/"]')

                record = {
                    "source": "Quotes to Scrape",
                    "source_url": url,
                    "name_or_title": (
                        text_element.get_text(strip=True)
                        if text_element
                        else None
                    ),
                    "category": None,
                    "price": None,
                    "rating": None,
                    "author": (
                        author_element.get_text(strip=True)
                        if author_element
                        else None
                    ),
                    "tags": tags,
                    "description": None,
                    "author_url": (
                        urljoin(url, author_link["href"])
                        if author_link and author_link.get("href")
                        else None
                    ),
                }

                records.append(record)

            except Exception as exc:
                logger.warning(
                    "Could not parse quote on page %d: %s",
                    page_number,
                    exc,
                )

        next_link = soup.select_one("li.next > a")

        if next_link and next_link.get("href"):
            url = urljoin(url, next_link["href"])
            page_number += 1
            polite_delay()
        else:
            url = None

    logger.info("Quotes scraping completed. Records: %d", len(records))

    return records