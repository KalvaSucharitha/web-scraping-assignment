import logging
from urllib.parse import urljoin

from bs4 import BeautifulSoup

from scrapers.base_scraper import create_session, polite_delay

logger = logging.getLogger(__name__)

START_URL = "https://books.toscrape.com/"


def parse_book(article, page_url):
    """Extract one book from a listing page."""

    link = article.select_one("h3 > a")
    price = article.select_one("p.price_color")
    rating = article.select_one("p.star-rating")

    if not link:
        raise ValueError("Book title/link is missing")

    title = link.get("title") or link.get_text(strip=True)

    rating_text = None
    if rating:
        classes = rating.get("class", [])
        rating_text = " ".join(classes)

    return {
        "source": "Books to Scrape",
        "source_url": urljoin(page_url, link.get("href", "")),
        "name_or_title": title,
        "category": None,
        "price_raw": price.get_text(strip=True) if price else None,
        "rating_raw": rating_text,
        "author": None,
        "tags": None,
        "description": None,
    }


def scrape_books(session=None):
    """Scrape all book pages using the Next link."""

    if session is None:
        session = create_session()

    records = []
    url = START_URL
    page_number = 1

    while url:
        logger.info("Books page %d: %s", page_number, url)

        try:
            response = session.get(url, timeout=10)
            response.raise_for_status()
            response.encoding = "utf-8"

        except Exception as exc:
            logger.error("Failed to fetch books page %s: %s", url, exc)
            break

        soup = BeautifulSoup(response.text, "lxml")

        books = soup.select("article.product_pod")

        for book in books:
            try:
                record = parse_book(book, url)
                records.append(record)

            except Exception as exc:
                logger.warning(
                    "Could not parse a book on page %d: %s",
                    page_number,
                    exc
                )

        next_link = soup.select_one("li.next > a")

        if next_link and next_link.get("href"):
            url = urljoin(url, next_link["href"])
            page_number += 1
            polite_delay()
        else:
            url = None

    logger.info("Books scraping completed. Records: %d", len(records))

    return records