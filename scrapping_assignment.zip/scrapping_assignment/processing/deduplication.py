import hashlib
import re


def make_fingerprint(record):
    source = record.get("source", "")
    title = record.get("name_or_title", "")
    author = record.get("author", "")

    if source == "Books to Scrape":
        key = f"{source} {title}"

    else:
        quote_part = title[:50]
        key = f"{source} {author} {quote_part}"

    # Lowercase
    key = key.lower()

    # Remove punctuation
    key = re.sub(r"[^\w\s]", "", key)

    # Remove extra spaces
    key = " ".join(key.split())

    # Create hash
    return hashlib.sha256(
        key.encode("utf-8")
    ).hexdigest()


def find_duplicates(records):
    seen = set()
    unique_records = []
    duplicate_records = []

    for record in records:
        fingerprint = make_fingerprint(record)

        if fingerprint in seen:
            duplicate_records.append(record)
        else:
            seen.add(fingerprint)
            unique_records.append(record)

    return unique_records, duplicate_records