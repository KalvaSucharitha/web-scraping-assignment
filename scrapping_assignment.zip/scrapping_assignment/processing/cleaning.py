import re
from urllib.parse import urljoin


RATING_MAP = {
    "one": 1,
    "two": 2,
    "three": 3,
    "four": 4,
    "five": 5,
}


def clean_text(value):
    if value is None:
        return None

    text = str(value).replace("\xa0", " ")
    text = " ".join(text.split())

    return text if text else None


def strip_quotes(value):
    if value is None:
        return None

    text = clean_text(value)

    if not text:
        return None

    return text.strip("")


def clean_price(value):
    if value is None:
        return None

    match = re.search(r"\d+(?:\.\d+)?", str(value).replace(",", ""))

    if match:
        return float(match.group())

    return None


def clean_rating(value):
    if value is None:
        return None

    text = str(value).lower()

    for word, number in RATING_MAP.items():
        if word in text:
            return number

    return None


def clean_tags(tags):
    if not tags:
        return None

    if isinstance(tags, str):
        tags = tags.split(";")

    cleaned = []

    for tag in tags:
        tag = clean_text(tag)

        if tag:
            cleaned.append(tag.lower())

    cleaned = sorted(set(cleaned))

    return ";".join(cleaned) if cleaned else None


def normalize_url(url, base_url=None):
    if not url:
        return None

    url = clean_text(url)

    if not url:
        return None

    if base_url:
        url = urljoin(base_url, url)

    if url.startswith(("http://", "https://")):
        return url

    return None