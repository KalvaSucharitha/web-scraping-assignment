# AI Usage

## Tool Used

ChatGPT was used as an AI assistance tool during development.

## How AI Was Used

AI assistance was used for:

- Understanding the assignment requirements.
- Planning the project structure.
- Creating the scraper modules.
- Understanding pagination using the Next link.
- Creating data cleaning functions.
- Creating validation logic.
- Creating deduplication logic.
- Debugging Python errors.
- Creating README documentation.

## Representative Prompts

Examples of prompts used:

- "Help me understand the web scraping ETL assignment."
- "How can I scrape all pages using the Next link?"
- "Help me create Python cleaning and validation functions."
- "Help me debug the Python scraper."
- "Help me create the README documentation."

## Assisted Parts

AI assistance was used for the initial code structure, explanations, debugging, and documentation.

The final code was reviewed and tested by running the scraper locally.

## Changes After Review

The generated code was reviewed and adjusted to match the assignment requirements.

Changes included:

- Using pagination instead of hard-coded page numbers.
- Adding cleaning and validation.
- Adding deduplication.
- Adding retry and logging support.
- Adding CSV and JSON output files.
- Handling errors without stopping the complete pipeline.

## Mistakes and Corrections

During development, some issues occurred, including a Python encoding error and missing/incorrect file formatting.

These issues were corrected and the pipeline was run again successfully.

## Testing

The final pipeline was tested by running:

python main.py

The scraper successfully collected:

- 1000 book records
- 100 quote records

Total scraped records: 1100

After deduplication:

- Unique records: 1099
- Duplicates removed: 1
- Invalid records: 0

The final CSV and summary JSON files were generated successfully.