﻿# Web Scraping ETL Assignment

## Overview

This project is a Python ETL pipeline that scrapes data from:

- Books to Scrape: https://books.toscrape.com/
- Quotes to Scrape: https://quotes.toscrape.com/

The scraped data is cleaned, validated, deduplicated, and exported into a common dataset.

## Project Structure

```text
scrapping_assignment/
├── scrapers/
│   ├── base_scraper.py
│   ├── books_scraper.py
│   └── quotes_scraper.py
├── processing/
│   ├── cleaning.py
│   ├── validation.py
│   └── deduplication.py
├── output/
│   ├── final_dataset.csv
│   └── summary_report.json
├── logs/
│   └── scraper.log
├── main.py
├── requirements.txt
├── README.md
└── AI_USAGE.md
Requirements
Python 3.10 or above
requests
beautifulsoup4
lxml
pandas
Installation
Install the required packages:
pip install -r requirements.txt
Running the Scraper
Run the complete ETL pipeline:
python main.py
The pipeline scrapes both websites, cleans the records, validates them, removes duplicates, and saves the final results.
Pagination
The scraper follows the li.next > a link on each website.
It does not hard-code page numbers and continues until there is no next page.
Common Data Schema
The final dataset uses these fields:
source
source_url
name_or_title
category
price
rating
author
tags
description
Data Cleaning
The pipeline:
Removes extra whitespace.
Normalizes text.
Cleans prices into numeric values.
Converts ratings into numbers from 1 to 5.
Cleans and normalizes tags.
Normalizes URLs.
Removes unnecessary quotation marks from quote text.
Validation
Each record is checked for:
Valid source
Non-empty name or title
Valid HTTP/HTTPS URL
Valid non-negative price when available
Valid rating from 1 to 5 when available
Invalid records are rejected without stopping the complete pipeline.
Deduplication
Records are deduplicated using normalized fingerprints.
For books:
source + title
For quotes:
source + author + first 50 characters of quote
Punctuation and extra spaces are normalized before generating the fingerprint.
Error Handling
The scraper uses:
Requests sessions
Retry handling for temporary HTTP errors
Logging
Per-record exception handling
Timeout handling
A 0.5 second delay between book page requests
Output Files
final_dataset.csv
Contains the final cleaned, validated, and deduplicated records.
summary_report.json
Contains summary statistics such as:
Books scraped
Quotes scraped
Total records
Cleaned records
Unique records
Duplicates removed
Valid records
Invalid records
scraper.log
Contains execution logs, scraping progress, warnings, and errors.
Assumptions and Limitations
Some fields may be empty when they are not available on listing pages.
The quote source_url represents the page where the quote appeared.
The scraper depends on the current HTML structure of the websites.
The websites are public practice websites used for scraping exercises.
AI Usage
AI assistance was used during development for understanding the assignment, code structure, debugging, and documentation.
Details are documented in AI_USAGE.md.
Final Result
The pipeline successfully scraped both sources and generated the required CSV and JSON output files.