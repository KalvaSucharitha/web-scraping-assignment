
import csv
import logging
import json
from pathlib import Path

from scrapers.base_scraper import create_session
from scrapers.books_scraper import scrape_books
from scrapers.quotes_scraper import scrape_quotes

from processing.cleaning import (
    clean_text,
    strip_quotes,
    clean_price,
    clean_rating,
    clean_tags,
    normalize_url,
)

from processing.deduplication import find_duplicates
from processing.validation import validate_record


# -------------------------------------------------
# Paths
# -------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "output"
LOG_DIR = BASE_DIR / "logs"

OUTPUT_DIR.mkdir(exist_ok=True)
LOG_DIR.mkdir(exist_ok=True)

FINAL_FILE = OUTPUT_DIR / "final_dataset.csv"


# -------------------------------------------------
# Logging
# -------------------------------------------------

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "scraping.log", encoding="utf-8"),
        logging.StreamHandler(),
    ],
)

logger = logging.getLogger(__name__)


# -------------------------------------------------
# Clean one record
# -------------------------------------------------

def clean_record(record):
    cleaned = {
        "source": clean_text(record.get("source")),
        "source_url": normalize_url(record.get("source_url")),
        "name_or_title": strip_quotes(record.get("name_or_title")),
        "category": clean_text(record.get("category")),
        "price": clean_price(
            record.get("price")
            if record.get("price") is not None
            else record.get("price_raw")
        ),
        "rating": clean_rating(
            record.get("rating")
            if record.get("rating") is not None
            else record.get("rating_raw")
        ),
        "author": clean_text(record.get("author")),
        "tags": clean_tags(record.get("tags")),
        "description": clean_text(record.get("description")),
    }

    return cleaned


# -------------------------------------------------
# Save CSV
# -------------------------------------------------

def save_csv(records, file_path):
    fieldnames = [
        "source",
        "source_url",
        "name_or_title",
        "category",
        "price",
        "rating",
        "author",
        "tags",
        "description",
    ]

    with open(file_path, "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(records)


# -------------------------------------------------
# Main pipeline
# -------------------------------------------------

def main():
    logger.info("Scraping assignment started.")

    session = create_session()

    # 1. Scrape Books
    logger.info("Starting books scraping...")
    books = scrape_books(session)

    # 2. Scrape Quotes
    logger.info("Starting quotes scraping...")
    quotes = scrape_quotes(session)

    # Combine both datasets
    records = books + quotes

    logger.info(
        "Scraping completed. Books: %d | Quotes: %d | Total: %d",
        len(books),
        len(quotes),
        len(records),
    )

    # 3. Cleaning
    cleaned_records = []

    for record in records:
        try:
            cleaned = clean_record(record)
            cleaned_records.append(cleaned)

        except Exception as exc:
            logger.warning(
                "Could not clean record: %s",
                exc,
            )

    logger.info(
        "Cleaning completed. Records: %d",
        len(cleaned_records),
    )

    # 4. Remove duplicates
    unique_records, duplicate_records = find_duplicates(
        cleaned_records
    )

    logger.info(
        "Deduplication completed. Unique: %d | Duplicates: %d",
        len(unique_records),
        len(duplicate_records),
    )

    # 5. Validation
    valid_records = []
    invalid_records = []

    for record in unique_records:
        problems = validate_record(record)

        if problems:
            record["validation_errors"] = ";".join(problems)
            invalid_records.append(record)

        else:
            valid_records.append(record)

    logger.info(
        "Validation completed. Valid: %d | Invalid: %d",
        len(valid_records),
        len(invalid_records),
    )

    # 6. Save final dataset
    save_csv(valid_records, FINAL_FILE)

    summary = {
        "books_scraped": len(books),
        "quotes_scraped": len(quotes),
        "total_scraped": len(records),
        "cleaned_records": len(cleaned_records),
        "unique_records": len(unique_records),
        "duplicates_removed": len(duplicate_records),
        "valid_records": len(valid_records),
        "invalid_records": len(invalid_records),
    }

    summary_file = OUTPUT_DIR / "summary_report.json"

    with open(summary_file, "w", encoding="utf-8") as file:
        json.dump(summary, file, indent=4)

    logger.info("Summary report saved to: %s", summary_file)
    logger.info(
        "Final dataset saved to: %s",
        FINAL_FILE,
    )

    logger.info("Scraping assignment completed successfully.")


if __name__ == "__main__":
    main()